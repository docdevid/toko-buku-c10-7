<?php

if (!function_exists('getAppName')) {
    function getAppName()
    {
        return 'tokobuku.com';
    }
}
