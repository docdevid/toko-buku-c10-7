<?php

namespace Config;

use CodeIgniter\Config\BaseConfig;

class MyConfig extends BaseConfig
{
    public $siteName = 'Agoritma A star';
    public $baseCoordinate = '-7.787842533743108, 110.36908210785771';
}
