<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class StatusPembayaranSeeder extends Seeder
{
    public function run()
    {
        //
    }
}
